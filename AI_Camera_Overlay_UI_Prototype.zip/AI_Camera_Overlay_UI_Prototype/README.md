# AI Camera Overlay 1.0 UI Prototype

Prototype for Xiaomi 17 / HyperOS 4.

## Included in this first UI milestone
- Dark Flow Glass-inspired launch screen.
- Draggable floating AI bubble.
- Compact translucent assistant panel with Leica-orange accent.
- Overlay permission flow.
- GitHub Actions debug APK workflow.

## Not included yet
- MediaProjection capture and its consent flow.
- Pose or composition inference.
- Real-time camera frame analysis.
- Camera control or photo processing.

This prototype deliberately displays sample guidance and labels it as a UI test. It does not claim to analyze the camera preview yet.

## Build
Use JDK 17 and Gradle 8.9 or a compatible Gradle 8.x distribution with Android Gradle Plugin 8.7.3.
Run `gradle assembleDebug`.

GitHub Actions builds a debug APK on push to `main` or manual workflow dispatch.
