package vn.lekien.aicameraoverlay

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import vn.lekien.aicameraoverlay.overlay.OverlayService

class MainActivity : Activity() {
    private val orange = Color.rgb(243, 107, 50)
    private val bg = Color.rgb(19, 22, 27)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = bg
        window.navigationBarColor = bg
        window.decorView.systemUiVisibility = 0

        val page = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(24), dp(34), dp(24), dp(24))
            setBackgroundColor(bg)
        }

        page.addView(label("AI CAMERA OVERLAY", 12, orange, true))
        page.addView(label("Flow Glass UI 1.0", 28, Color.WHITE, true).withTop(8))
        page.addView(label("Trợ lý bố cục chụp ảnh cho Camera Xiaomi", 14, 0xFFB7C0CA.toInt()).withTop(8))

        val preview = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(18), dp(18), dp(18))
            background = rounded(0xFF292F37.toInt(), 24, 0x44FFFFFF)
        }
        preview.addView(label("GIAO DIỆN ĐÃ CHỐT", 11, orange, true))
        preview.addView(label("Kính trong suốt · Blur nhẹ · Cam Leica", 16, Color.WHITE, true).withTop(10))
        preview.addView(label("Bản này tập trung kiểm tra bong bóng nổi và bảng kính. AI phân tích camera sẽ được tích hợp ở bước sau.", 13, 0xFFD0D5DB.toInt()).withTop(8))
        page.addView(preview.withTop(28))

        val start = Button(this).apply {
            text = "BẬT BONG BÓNG AI"
            setTextColor(Color.WHITE)
            isAllCaps = false
            textSize = 15f
            background = rounded(orange, 18)
            setOnClickListener {
                if (!Settings.canDrawOverlays(this@MainActivity)) {
                    val intent = Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                        Uri.parse("package:$packageName"))
                    startActivity(intent)
                } else {
                    startService(Intent(this@MainActivity, OverlayService::class.java))
                    finish()
                }
            }
        }
        page.addView(start.withTop(24).apply {
            layoutParams = (layoutParams as LinearLayout.LayoutParams).apply {
                height = dp(56)
            }
        })

        page.addView(label("Chỉ yêu cầu quyền hiển thị trên ứng dụng khác. Không dùng Accessibility và không cần root.", 12, 0xFF9DA7B2.toInt()).withTop(18))
        setContentView(page)
    }

    private fun label(text: String, size: Int, color: Int, bold: Boolean = false) =
        TextView(this).apply {
            this.text = text
            textSize = size.toFloat()
            setTextColor(color)
            if (bold) typeface = Typeface.DEFAULT_BOLD
        }

    private fun rounded(color: Int, radius: Int, stroke: Int = 0): GradientDrawable =
        GradientDrawable().apply {
            setColor(color)
            cornerRadius = dp(radius).toFloat()
            if (stroke != 0) setStroke(dp(1), stroke)
        }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun View.withTop(margin: Int): View {
        layoutParams = LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            LinearLayout.LayoutParams.WRAP_CONTENT
        ).apply { topMargin = dp(margin) }
        return this
    }
}
