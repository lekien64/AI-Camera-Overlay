package vn.lekien.aicameraoverlay.overlay

import android.app.Service
import android.content.Intent
import android.content.res.Configuration
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.IBinder
import android.view.Gravity
import android.view.OrientationEventListener
import android.view.Surface
import android.view.View
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.TextView

class OverlayService : Service() {
    private lateinit var wm: WindowManager
    private var bubble: View? = null
    private var panel: View? = null
    private var panelOpen = false
    private val orange = Color.rgb(243, 107, 50)

    // Camera apps can rotate their own UI without rotating the Android display.
    // The physical orientation sensor is therefore the primary orientation source.
    private var sensorLandscape = false
    private lateinit var orientationListener: OrientationEventListener

    private val isLandscape: Boolean
        get() = sensorLandscape ||
            resources.configuration.orientation == Configuration.ORIENTATION_LANDSCAPE

    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        showBubble()

        orientationListener = object : OrientationEventListener(this) {
            override fun onOrientationChanged(degrees: Int) {
                if (degrees == ORIENTATION_UNKNOWN) return
                val nextLandscape = when {
                    degrees in 60..120 || degrees in 240..300 -> true
                    degrees in 0..30 || degrees in 150..210 || degrees in 330..359 -> false
                    else -> sensorLandscape
                }
                if (nextLandscape != sensorLandscape) {
                    sensorLandscape = nextLandscape
                    refreshForOrientation()
                }
            }
        }
        if (orientationListener.canDetectOrientation()) orientationListener.enable()
    }

    private fun refreshForOrientation() {
        if (panelOpen) {
            panel?.let { runCatching { wm.removeView(it) } }
            panel = null
            panelOpen = false
            showPanel()
        }
        bubble?.let { view ->
            val lp = view.layoutParams as? WindowManager.LayoutParams ?: return@let
            lp.y = if (isLandscape) dp(55) else dp(245)
            runCatching { wm.updateViewLayout(view, lp) }
        }
    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        // Keep this fallback for devices that do rotate the Android display.
        if (newConfig.orientation == Configuration.ORIENTATION_LANDSCAPE) {
            sensorLandscape = true
        } else if (newConfig.orientation == Configuration.ORIENTATION_PORTRAIT) {
            sensorLandscape = false
        }
        refreshForOrientation()
    }

    private fun overlayType() =
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        else @Suppress("DEPRECATION") WindowManager.LayoutParams.TYPE_PHONE

    private fun makeParams(width: Int, height: Int, touchable: Boolean = true) =
        WindowManager.LayoutParams(
            width, height, overlayType(),
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                (if (touchable) WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                 else WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                      WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE),
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = if (isLandscape) Gravity.CENTER else Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL
            x = if (isLandscape) dp(0) else dp(0)
            // In portrait, keep the card just above the camera mode selector.
            y = if (isLandscape) dp(0) else dp(300)
            // Keep below Android's default maximum obscuring opacity for pass-through touches.
            // Raising this from 0.56 improves legibility while retaining touch-through.
            alpha = if (touchable) 1.0f else 0.78f
        }

    private fun showBubble() {
        val view = TextView(this).apply {
            text = "◎"
            textSize = 30f
            gravity = Gravity.CENTER
            setTextColor(Color.WHITE)
            background = glass(0xAA252B32.toInt(), 0x99F36B32.toInt(), 100)
            elevation = dp(8).toFloat()
            contentDescription = "Mở hoặc đóng AI Camera Assistant"
            setOnClickListener { togglePanel() }
            setOnTouchListener(DragTouch())
        }
        bubble = view
        wm.addView(view, makeParams(dp(58), dp(58), touchable = true))
    }

    private fun togglePanel() {
        if (panelOpen) {
            panel?.let { runCatching { wm.removeView(it) } }
            panel = null
            panelOpen = false
        } else {
            showPanel()
        }
    }

    private fun showPanel() {
        // The landscape camera preview on some Xiaomi builds rotates independently
        // from the Android display. Keep the panel in portrait window coordinates,
        // compose it as a portrait card, then rotate the complete card as one unit.
        // This makes the frame, typography and all child views turn together.
        val metrics = resources.displayMetrics
        val shortEdge = minOf(metrics.widthPixels, metrics.heightPixels)
        val longEdge = maxOf(metrics.widthPixels, metrics.heightPixels)

        val landscape = isLandscape
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_VERTICAL
            // Keep the same soft glass treatment in both orientations.
            // Landscape uses tighter insets because its content is rotated as one unit.
            val inset = if (landscape) 10 else 14
            setPadding(dp(inset), dp(inset), dp(inset), dp(inset))
            background = glass(0xD91C2229.toInt(), 0x88FFFFFF.toInt(), 30)
            elevation = dp(12).toFloat()
        }

        // One compact type scale shared by portrait and landscape.
        val titleSize = 14
        val statusSize = 10
        val sectionSize = 11
        val suggestionSize = 12
        val detailSize = 10
        val sectionGap = if (landscape) 8 else 12
        val suggestionGap = if (landscape) 5 else 7
        val detailGap = if (landscape) 6 else 9

        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            addView(makeText("AI CAMERA", titleSize, Color.WHITE, true),
                LinearLayout.LayoutParams(0, -2, 1f))
            addView(makeText("● SẴN SÀNG", statusSize, 0xFF8BE0B4.toInt(), true))
        }
        card.addView(header)
        card.addView(makeText("GỢI Ý BỐ CỤC", sectionSize, orange, true)
            .withTop(sectionGap))
        card.addView(makeText(
            "Đưa chủ thể gần đường 1/3 để khung hình cân đối hơn.",
            suggestionSize, Color.WHITE
        ).withTop(suggestionGap))
        card.addView(makeText(
            "Chạm xuyên đã bật · AI chưa phân tích hình ảnh.",
            detailSize, 0xFFE4E8ED.toInt()
        ).withTop(detailGap))

        val lp = if (isLandscape) {
            // Width/height are deliberately portrait-shaped BEFORE rotation.
            // After rotation the visible bounds become a wide landscape card.
            card.rotation = 90f
            WindowManager.LayoutParams(
                // Pre-rotation dimensions: compact height, broad width.
                // After 90-degree rotation this becomes a wide, low landscape card.
                (shortEdge * 0.30f).toInt(),
                (longEdge * 0.84f).toInt(),
                overlayType(),
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                    WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE,
                PixelFormat.TRANSLUCENT
            ).apply {
                gravity = Gravity.CENTER
                // A positive pre-rotation X offset moves the rotated card toward
                // the bottom edge of the landscape camera preview.
                x = dp(90)
                alpha = 0.88f
            }
        } else {
            makeParams(dp(300), WindowManager.LayoutParams.WRAP_CONTENT, touchable = false)
                .apply { alpha = 0.88f }
        }

        panel = card
        wm.addView(card, lp)
        panelOpen = true
    }

    private inner class DragTouch : View.OnTouchListener {
        private var downX = 0f
        private var downY = 0f
        private var startX = 0
        private var startY = 0
        private var moved = false

        override fun onTouch(v: View, event: android.view.MotionEvent): Boolean {
            val lp = v.layoutParams as WindowManager.LayoutParams
            when (event.action) {
                android.view.MotionEvent.ACTION_DOWN -> {
                    downX = event.rawX
                    downY = event.rawY
                    startX = lp.x
                    startY = lp.y
                    moved = false
                    return true
                }
                android.view.MotionEvent.ACTION_MOVE -> {
                    val dx = (event.rawX - downX).toInt()
                    val dy = (event.rawY - downY).toInt()
                    if (kotlin.math.abs(dx) + kotlin.math.abs(dy) > dp(6)) moved = true
                    lp.x = startX + dx
                    lp.y = startY + dy
                    wm.updateViewLayout(v, lp)
                    return true
                }
                android.view.MotionEvent.ACTION_UP -> {
                    if (!moved) v.performClick()
                    return true
                }
            }
            return false
        }
    }

    private fun makeText(value: String, size: Int, color: Int, bold: Boolean = false) =
        TextView(this).apply {
            text = value
            textSize = size.toFloat()
            setTextColor(color)
            if (bold) typeface = Typeface.DEFAULT_BOLD
        }

    private fun glass(color: Int, stroke: Int, radius: Int) =
        GradientDrawable().apply {
            setColor(color)
            cornerRadius = dp(radius).toFloat()
            if (stroke != 0) setStroke(dp(1), stroke)
        }

    private fun View.withTop(value: Int): View {
        layoutParams = LinearLayout.LayoutParams(-1, -2).apply {
            topMargin = dp(value)
        }
        return this
    }

    private fun dp(value: Int) =
        (value * resources.displayMetrics.density).toInt()

    override fun onDestroy() {
        if (::orientationListener.isInitialized) orientationListener.disable()
        panel?.let { runCatching { wm.removeView(it) } }
        bubble?.let { runCatching { wm.removeView(it) } }
        panel = null
        bubble = null
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
