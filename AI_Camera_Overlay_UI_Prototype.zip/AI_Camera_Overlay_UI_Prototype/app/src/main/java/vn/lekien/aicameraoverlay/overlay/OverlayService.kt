package vn.lekien.aicameraoverlay.overlay

import android.app.Service
import android.content.Intent
import android.content.res.Configuration
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.IBinder
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.TextView

class OverlayService : Service() {
    private lateinit var wm: WindowManager
    private var bubble: View? = null
    private var panel: View? = null
    private var panelOpen = false
    private val orange = Color.rgb(243, 107, 50)

    private val isLandscape: Boolean
        get() = resources.configuration.orientation == Configuration.ORIENTATION_LANDSCAPE

    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        showBubble()
    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        if (panelOpen) {
            panel?.let { runCatching { wm.removeView(it) } }
            panel = null
            panelOpen = false
            showPanel()
        }
        bubble?.let { view ->
            val lp = view.layoutParams as? WindowManager.LayoutParams ?: return@let
            val metrics = resources.displayMetrics
            lp.x = lp.x.coerceIn(0, (metrics.widthPixels - dp(58)).coerceAtLeast(0))
            lp.y = lp.y.coerceIn(0, (metrics.heightPixels - dp(58)).coerceAtLeast(0))
            runCatching { wm.updateViewLayout(view, lp) }
        }
    }

    private fun overlayType() =
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        else @Suppress("DEPRECATION") WindowManager.LayoutParams.TYPE_PHONE

    private fun makeParams(width: Int, height: Int, touchable: Boolean = true) =
        WindowManager.LayoutParams(
            width, height, overlayType(),
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                (if (touchable) WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                 else WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                      WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE),
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = dp(18)
            y = if (isLandscape) dp(55) else dp(245)
            // Keep the overlay below Android's obscuring-opacity threshold so
            // touches can pass through to the stock Camera underneath.
            alpha = if (touchable) 1.0f else 0.56f
        }

    private fun showBubble() {
        val view = TextView(this).apply {
            text = "◎"
            textSize = 30f
            gravity = Gravity.CENTER
            setTextColor(Color.WHITE)
            background = glass(0xAA252B32.toInt(), 0x99F36B32.toInt(), 100)
            elevation = dp(8).toFloat()
            contentDescription = "Mở hoặc đóng AI Camera Assistant"
            setOnClickListener { togglePanel() }
            setOnTouchListener(DragTouch())
        }
        bubble = view
        wm.addView(view, makeParams(dp(58), dp(58), touchable = true))
    }

    private fun togglePanel() {
        if (panelOpen) {
            panel?.let { runCatching { wm.removeView(it) } }
            panel = null
            panelOpen = false
        } else {
            showPanel()
        }
    }

    private fun showPanel() {
        val card = LinearLayout(this).apply {
            orientation = if (isLandscape) LinearLayout.HORIZONTAL else LinearLayout.VERTICAL
            setPadding(dp(15), dp(13), dp(15), dp(13))
            background = glass(0x881C2229.toInt(), 0x44FFFFFF, 22)
            elevation = dp(12).toFloat()
        }

        if (isLandscape) {
            val left = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                addView(makeText("AI CAMERA", 15, Color.WHITE, true))
                addView(makeText("● SẴN SÀNG", 10, 0xFF8BE0B4.toInt(), true).withTop(8))
            }
            val right = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                addView(makeText("GỢI Ý BỐ CỤC", 10, orange, true))
                addView(makeText("Đưa chủ thể gần đường 1/3 để khung hình cân đối hơn.", 13, Color.WHITE).withTop(6))
                addView(makeText("Bảng đang ở chế độ chạm xuyên · AI chưa phân tích ảnh.", 9, 0xFFD0D5DB.toInt()).withTop(7))
            }
            card.addView(left, LinearLayout.LayoutParams(0, -2, 0.8f).apply {
                marginEnd = dp(14)
            })
            card.addView(right, LinearLayout.LayoutParams(0, -2, 1.5f))
        } else {
            val header = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                addView(makeText("AI CAMERA", 14, Color.WHITE, true),
                    LinearLayout.LayoutParams(0, -2, 1f))
                addView(makeText("● SẴN SÀNG", 10, 0xFF8BE0B4.toInt(), true))
            }
            card.addView(header)
            card.addView(makeText("Gợi ý bố cục", 10, orange, true).withTop(15))
            card.addView(makeText("Đưa chủ thể gần đường 1/3 để khung hình cân đối hơn.", 13, Color.WHITE).withTop(6))
            card.addView(makeText("Chạm xuyên đã bật · AI chưa phân tích hình ảnh.", 10, 0xFFD0D5DB.toInt()).withTop(10))
        }

        val screenWidth = resources.displayMetrics.widthPixels
        val panelWidth = if (isLandscape)
            (screenWidth * 0.62f).toInt().coerceAtMost(dp(520))
        else dp(286)

        panel = card
        // The panel is visible but deliberately non-touchable.
        // Every tap in its rectangle is delivered to the Camera app below.
        wm.addView(card, makeParams(panelWidth, WindowManager.LayoutParams.WRAP_CONTENT, touchable = false))
        panelOpen = true
    }

    private inner class DragTouch : View.OnTouchListener {
        private var downX = 0f
        private var downY = 0f
        private var startX = 0
        private var startY = 0
        private var moved = false

        override fun onTouch(v: View, event: MotionEvent): Boolean {
            val lp = v.layoutParams as WindowManager.LayoutParams
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    downX = event.rawX
                    downY = event.rawY
                    startX = lp.x
                    startY = lp.y
                    moved = false
                    return true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (event.rawX - downX).toInt()
                    val dy = (event.rawY - downY).toInt()
                    if (kotlin.math.abs(dx) + kotlin.math.abs(dy) > dp(6)) moved = true
                    lp.x = startX + dx
                    lp.y = startY + dy
                    wm.updateViewLayout(v, lp)
                    return true
                }
                MotionEvent.ACTION_UP -> {
                    if (!moved) v.performClick()
                    return true
                }
            }
            return false
        }
    }

    private fun makeText(value: String, size: Int, color: Int, bold: Boolean = false) =
        TextView(this).apply {
            text = value
            textSize = size.toFloat()
            setTextColor(color)
            if (bold) typeface = Typeface.DEFAULT_BOLD
        }

    private fun glass(color: Int, stroke: Int, radius: Int) =
        GradientDrawable().apply {
            setColor(color)
            cornerRadius = dp(radius).toFloat()
            if (stroke != 0) setStroke(dp(1), stroke)
        }

    private fun View.withTop(value: Int): View {
        layoutParams = LinearLayout.LayoutParams(-1, -2).apply {
            topMargin = dp(value)
        }
        return this
    }

    private fun dp(value: Int) =
        (value * resources.displayMetrics.density).toInt()

    override fun onDestroy() {
        panel?.let { runCatching { wm.removeView(it) } }
        bubble?.let { runCatching { wm.removeView(it) } }
        panel = null
        bubble = null
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
