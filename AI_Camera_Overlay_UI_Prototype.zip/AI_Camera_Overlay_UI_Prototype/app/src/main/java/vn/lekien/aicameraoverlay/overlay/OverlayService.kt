package vn.lekien.aicameraoverlay.overlay

import android.app.Service
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.IBinder
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.TextView

class OverlayService : Service() {
    private lateinit var wm: WindowManager
    private var bubble: View? = null
    private var panel: View? = null
    private var panelOpen = false
    private val orange = Color.rgb(243, 107, 50)

    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        showBubble()
    }

    private fun overlayType() =
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        else @Suppress("DEPRECATION") WindowManager.LayoutParams.TYPE_PHONE

    private fun params(width: Int, height: Int, gravity: Int = Gravity.TOP or Gravity.START) =
        WindowManager.LayoutParams(width, height, overlayType(),
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT).apply {
            this.gravity = gravity
            x = dp(18); y = dp(180)
        }

    private fun showBubble() {
        val b = TextView(this).apply {
            text = "◉"
            textSize = 28f
            gravity = Gravity.CENTER
            setTextColor(Color.WHITE)
            background = glass(0xE6252B32.toInt(), orange)
            elevation = dp(8).toFloat()
            setOnClickListener { togglePanel() }
            setOnTouchListener(DragTouch())
            contentDescription = "Mở AI Camera Assistant"
        }
        bubble = b
        wm.addView(b, params(dp(58), dp(58)))
    }

    private fun togglePanel() {
        if (panelOpen) {
            panel?.let { wm.removeView(it) }
            panel = null
            panelOpen = false
        } else {
            showPanel()
        }
    }

    private fun showPanel() {
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(16), dp(18), dp(16))
            background = glass(0xE61C2229.toInt(), 0x55FFFFFF)
            elevation = dp(12).toFloat()
        }
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        header.addView(text("AI CAMERA", 15, Color.WHITE, true), LinearLayout.LayoutParams(0, -2, 1f))
        header.addView(text("● SẴN SÀNG", 10, 0xFF8BE0B4.toInt(), true))
        card.addView(header)
        card.addView(text("Gợi ý bố cục", 11, orange, true).top(18))
        card.addView(text("Đưa chủ thể gần đường 1/3 để khung hình cân đối hơn.", 14, Color.WHITE).top(7))
        card.addView(text("Chế độ hiện tại: giao diện thử nghiệm. AI chưa phân tích hình ảnh.", 11, 0xFFB9C2CC.toInt()).top(12))
        val close = TextView(this).apply {
            text = "ĐÓNG BẢNG"
            textSize = 11f
            gravity = Gravity.CENTER
            setTextColor(Color.WHITE)
            background = glass(orange, 0)
            setPadding(dp(12), dp(12), dp(12), dp(12))
            setOnClickListener { togglePanel() }
        }
        card.addView(close.top(16))
        panel = card
        val p = params(dp(286), -2).apply {
            x = dp(18)
            y = dp(250)
        }
        wm.addView(card, p)
        panelOpen = true
    }

    private inner class DragTouch : View.OnTouchListener {
        private var downX = 0f; private var downY = 0f
        private var startX = 0; private var startY = 0
        private var moved = false
        override fun onTouch(v: View, e: MotionEvent): Boolean {
            val lp = v.layoutParams as WindowManager.LayoutParams
            when (e.action) {
                MotionEvent.ACTION_DOWN -> {
                    downX = e.rawX; downY = e.rawY
                    startX = lp.x; startY = lp.y; moved = false
                    return true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (e.rawX - downX).toInt()
                    val dy = (e.rawY - downY).toInt()
                    if (kotlin.math.abs(dx) + kotlin.math.abs(dy) > dp(6)) moved = true
                    lp.x = startX + dx; lp.y = startY + dy
                    wm.updateViewLayout(v, lp)
                    return true
                }
                MotionEvent.ACTION_UP -> {
                    if (!moved) v.performClick()
                    return true
                }
            }
            return false
        }
    }

    private fun text(s: String, size: Int, color: Int, bold: Boolean = false) =
        TextView(this).apply {
            text = s; textSize = size.toFloat(); setTextColor(color)
            if (bold) typeface = Typeface.DEFAULT_BOLD
        }

    private fun glass(color: Int, stroke: Int): GradientDrawable =
        GradientDrawable().apply {
            setColor(color); cornerRadius = dp(22).toFloat()
            if (stroke != 0) setStroke(dp(1), stroke)
        }

    private fun View.top(v: Int): View {
        layoutParams = LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(v) }
        return this
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onDestroy() {
        panel?.let { runCatching { wm.removeView(it) } }
        bubble?.let { runCatching { wm.removeView(it) } }
        panel = null; bubble = null
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
