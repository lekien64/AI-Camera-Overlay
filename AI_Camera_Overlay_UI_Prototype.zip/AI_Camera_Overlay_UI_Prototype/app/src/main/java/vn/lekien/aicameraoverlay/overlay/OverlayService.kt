package vn.lekien.aicameraoverlay.overlay

import android.app.Service
import android.content.Intent
import android.content.res.Configuration
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.IBinder
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.TextView

class OverlayService : Service() {
    private lateinit var wm: WindowManager
    private var bubble: View? = null
    private var panel: View? = null
    private var panelOpen = false
    private val orange = Color.rgb(243, 107, 50)
    private val isLandscape: Boolean
        get() = resources.configuration.orientation == Configuration.ORIENTATION_LANDSCAPE

    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        showBubble()
    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        if (panelOpen) {
            panel?.let { runCatching { wm.removeView(it) } }
            panel = null
            panelOpen = false
            showPanel()
        }
    }

    private fun windowType() =
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        else @Suppress("DEPRECATION") WindowManager.LayoutParams.TYPE_PHONE

    private fun makeParams(width: Int, height: Int) =
        WindowManager.LayoutParams(
            width, height, windowType(),
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = dp(18)
            y = if (isLandscape) dp(60) else dp(250)
        }

    private fun showBubble() {
        val view = TextView(this).apply {
            text = "◎"
            textSize = 30f
            gravity = Gravity.CENTER
            setTextColor(Color.WHITE)
            background = glass(0xAA252B32.toInt(), 0x99F36B32.toInt(), 100)
            elevation = dp(8).toFloat()
            contentDescription = "Mở AI Camera Assistant"
            setOnClickListener { togglePanel() }
            setOnTouchListener(DragTouch())
        }
        bubble = view
        wm.addView(view, makeParams(dp(58), dp(58)))
    }

    private fun togglePanel() {
        if (panelOpen) {
            panel?.let { runCatching { wm.removeView(it) } }
            panel = null
            panelOpen = false
        } else showPanel()
    }

    private fun showPanel() {
        val card = LinearLayout(this).apply {
            orientation = if (isLandscape) LinearLayout.HORIZONTAL else LinearLayout.VERTICAL
            setPadding(dp(16), dp(14), dp(16), dp(14))
            background = glass(0x991C2229.toInt(), 0x55FFFFFF, 22)
            elevation = dp(12).toFloat()
        }

        if (isLandscape) {
            val left = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                addView(makeText("AI CAMERA", 16, Color.WHITE, true))
                addView(makeText("● SẴN SÀNG", 11, 0xFF8BE0B4.toInt(), true).withTop(10))
            }
            val right = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                addView(makeText("GỢI Ý BỐ CỤC", 11, orange, true))
                addView(makeText("Đưa chủ thể gần đường 1/3 để khung hình cân đối hơn.", 14, Color.WHITE).withTop(7))
                addView(makeText("Giao diện thử nghiệm · AI chưa phân tích hình ảnh.", 10, 0xFFD0D5DB.toInt()).withTop(8))
                addView(closeButton().withTop(10))
            }
            card.addView(left, LinearLayout.LayoutParams(0, -2, 0.8f).apply { marginEnd = dp(16) })
            card.addView(right, LinearLayout.LayoutParams(0, -2, 1.5f))
        } else {
            val header = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                addView(makeText("AI CAMERA", 15, Color.WHITE, true),
                    LinearLayout.LayoutParams(0, -2, 1f))
                addView(makeText("● SẴN SÀNG", 10, 0xFF8BE0B4.toInt(), true))
            }
            card.addView(header)
            card.addView(makeText("Gợi ý bố cục", 11, orange, true).withTop(18))
            card.addView(makeText("Đưa chủ thể gần đường 1/3 để khung hình cân đối hơn.", 14, Color.WHITE).withTop(7))
            card.addView(makeText("Chế độ hiện tại: giao diện thử nghiệm. AI chưa phân tích hình ảnh.", 11, 0xFFD0D5DB.toInt()).withTop(12))
            card.addView(closeButton().withTop(16))
        }

        val screenWidth = resources.displayMetrics.widthPixels
        val panelWidth = if (isLandscape) (screenWidth * 0.62f).toInt().coerceAtMost(dp(520)) else dp(286)
        panel = card
        wm.addView(card, makeParams(panelWidth, WindowManager.LayoutParams.WRAP_CONTENT))
        panelOpen = true
    }

    private fun closeButton() = TextView(this).apply {
        text = "ĐÓNG BẢNG"
        textSize = 11f
        gravity = Gravity.CENTER
        setTextColor(Color.WHITE)
        background = glass(0xCCF36B32.toInt(), 0, 16)
        setPadding(dp(12), dp(11), dp(12), dp(11))
        setOnClickListener { togglePanel() }
    }

    private inner class DragTouch : View.OnTouchListener {
        private var downX = 0f
        private var downY = 0f
        private var startX = 0
        private var startY = 0
        private var moved = false

        override fun onTouch(v: View, event: MotionEvent): Boolean {
            val lp = v.layoutParams as WindowManager.LayoutParams
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    downX = event.rawX; downY = event.rawY
                    startX = lp.x; startY = lp.y; moved = false
                    return true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (event.rawX - downX).toInt()
                    val dy = (event.rawY - downY).toInt()
                    if (kotlin.math.abs(dx) + kotlin.math.abs(dy) > dp(6)) moved = true
                    lp.x = startX + dx; lp.y = startY + dy
                    wm.updateViewLayout(v, lp)
                    return true
                }
                MotionEvent.ACTION_UP -> {
                    if (!moved) v.performClick()
                    return true
                }
            }
            return false
        }
    }

    private fun makeText(value: String, size: Int, color: Int, bold: Boolean = false) =
        TextView(this).apply {
            text = value
            textSize = size.toFloat()
            setTextColor(color)
            if (bold) typeface = Typeface.DEFAULT_BOLD
        }

    private fun glass(color: Int, stroke: Int, radius: Int) =
        GradientDrawable().apply {
            setColor(color)
            cornerRadius = dp(radius).toFloat()
            if (stroke != 0) setStroke(dp(1), stroke)
        }

    private fun View.withTop(value: Int): View {
        layoutParams = LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(value) }
        return this
    }

    private fun dp(value: Int) = (value * resources.displayMetrics.density).toInt()

    override fun onDestroy() {
        panel?.let { runCatching { wm.removeView(it) } }
        bubble?.let { runCatching { wm.removeView(it) } }
        panel = null
        bubble = null
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
