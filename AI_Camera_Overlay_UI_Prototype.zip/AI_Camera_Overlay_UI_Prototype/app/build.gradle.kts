plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "vn.lekien.aicameraoverlay"
    compileSdk = 35

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    kotlinOptions {
        jvmTarget = "17"
    }

    defaultConfig {
        applicationId = "vn.lekien.aicameraoverlay"
        minSdk = 26
        targetSdk = 35
        versionCode = 2
        versionName = "1.1-ui"
    }
}
